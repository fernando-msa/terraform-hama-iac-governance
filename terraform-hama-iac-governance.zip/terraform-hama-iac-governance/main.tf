############################################################
# main.tf
# Ponto de entrada: provider, data sources, locals de tags
# e composição dos módulos (tags, backup, monitoring) + policies/logs.
############################################################

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

# Provider AWS com tags padrão aplicadas automaticamente a TODOS os
# recursos que suportam tags (DIR.MMLN.TI.001 - Gestão de Ativos).
provider "aws" {
  region = var.aws_region

  default_tags {
    tags = local.tags_obrigatorias
  }
}

############################################################
# DATA SOURCES - buscam informações da conta/ambiente AWS
############################################################

# Identidade da conta em uso (account_id, arn do chamador).
data "aws_caller_identity" "current" {}

# Região atual (usada em ARNs e nomes).
data "aws_region" "current" {}

# Lista de zonas de disponibilidade da região (exemplo de data source).
data "aws_availability_zones" "available" {
  state = "available"
}

############################################################
# LOCALS - lógica centralizada das tags obrigatórias
# DIR.MMLN.TI.001: calcula DataFimVida = DataAquisicao + vida útil.
############################################################

locals {
  # Calcula a data de fim de vida somando a vida útil (em anos) à aquisição.
  # timeadd trabalha em horas: 8 anos ≈ 8 * 365 * 24 = 70080h.
  data_fim_vida = formatdate(
    "YYYY-MM-DD",
    timeadd("${var.data_aquisicao}T00:00:00Z", "${var.vida_util_anos * 8760}h")
  )

  # Conjunto de tags obrigatórias exigido pela DIR.MMLN.TI.001.
  tags_obrigatorias = {
    Setor         = var.setor
    DataAquisicao = var.data_aquisicao
    DataFimVida   = local.data_fim_vida
    Responsavel   = var.responsavel
    CustoCentro   = var.custo_centro
    ManagedBy     = "Terraform"
    Governanca    = "DIR.MMLN.TI.001"
  }

  # Sufixo único para nomes de bucket (precisam ser globalmente únicos).
  name_suffix = substr(sha256(data.aws_caller_identity.current.account_id), 0, 8)
}

############################################################
# MÓDULO: TAGS (DIR.MMLN.TI.001)
# Valida e expõe o conjunto de tags para uso em outros módulos.
############################################################

module "tags" {
  source = "./modules/tags"

  setor          = var.setor
  data_aquisicao = var.data_aquisicao
  data_fim_vida  = local.data_fim_vida
  responsavel    = var.responsavel
  custo_centro   = var.custo_centro
}

############################################################
# MÓDULO: BACKUP (POP.HAMA.TI.004)
############################################################

module "backup" {
  source = "./modules/backup"

  bucket_name   = "${var.project_prefix}-backup-ti-${local.name_suffix}"
  retencao_dias = var.backup_retencao_dias
  tags          = module.tags.tags
}

############################################################
# MÓDULO: MONITORING (POP.HAMA.TI.005 + Checklist Wi-Fi)
############################################################

module "monitoring" {
  source = "./modules/monitoring"

  project_prefix         = var.project_prefix
  sla_tempo_resposta_min = var.sla_tempo_resposta_min
  alarme_email           = var.alarme_email
  tags                   = module.tags.tags
}

############################################################
# MÓDULO: POLICIES (DIR.MMLN.TI.002 + FORM.HAMA.TI.015)
############################################################

module "policies" {
  source = "./policies"

  project_prefix = var.project_prefix
  tags           = module.tags.tags
  account_id     = data.aws_caller_identity.current.account_id
}

############################################################
# MÓDULO: LOGS / AUDITORIA (CloudTrail)
############################################################

module "logs" {
  source = "./logs"

  project_prefix = var.project_prefix
  tags           = module.tags.tags
  account_id     = data.aws_caller_identity.current.account_id
  name_suffix    = local.name_suffix
}
