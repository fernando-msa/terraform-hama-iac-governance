############################################################
# modules/tags/outputs.tf
# Expõe o mapa de tags para os demais módulos.
############################################################

output "tags" {
  description = "Mapa de tags obrigatórias (DIR.MMLN.TI.001)."
  value       = local.tags
}
