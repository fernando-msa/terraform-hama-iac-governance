############################################################
# logs/cloudtrail-logs.tf  (MÓDULO ./logs)
# Auditoria - registra TODAS as ações na conta (ISO 27001 A.12 / LGPD).
############################################################

# --- Entradas do módulo ---
variable "project_prefix" {
  description = "Prefixo de nomenclatura."
  type        = string
}

variable "tags" {
  description = "Tags obrigatórias."
  type        = map(string)
}

variable "account_id" {
  description = "ID da conta AWS."
  type        = string
}

variable "name_suffix" {
  description = "Sufixo único para o nome do bucket de logs."
  type        = string
}

# Bucket que armazena os logs do CloudTrail.
resource "aws_s3_bucket" "trail_logs" {
  bucket = "${var.project_prefix}-cloudtrail-logs-${var.name_suffix}"
  tags   = var.tags
}

resource "aws_s3_bucket_public_access_block" "trail_logs" {
  bucket = aws_s3_bucket.trail_logs.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Política exigida pelo CloudTrail para gravar logs no bucket.
resource "aws_s3_bucket_policy" "trail_logs" {
  bucket = aws_s3_bucket.trail_logs.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AWSCloudTrailAclCheck"
        Effect    = "Allow"
        Principal = { Service = "cloudtrail.amazonaws.com" }
        Action    = "s3:GetBucketAcl"
        Resource  = aws_s3_bucket.trail_logs.arn
      },
      {
        Sid       = "AWSCloudTrailWrite"
        Effect    = "Allow"
        Principal = { Service = "cloudtrail.amazonaws.com" }
        Action    = "s3:PutObject"
        Resource  = "${aws_s3_bucket.trail_logs.arn}/AWSLogs/${var.account_id}/*"
        Condition = {
          StringEquals = { "s3:x-amz-acl" = "bucket-owner-full-control" }
        }
      }
    ]
  })
}

# Trilha de auditoria de conta.
resource "aws_cloudtrail" "governance" {
  name                          = "${var.project_prefix}-governance-trail"
  s3_bucket_name                = aws_s3_bucket.trail_logs.id
  include_global_service_events = true
  is_multi_region_trail         = false
  enable_log_file_validation    = true

  tags       = var.tags
  depends_on = [aws_s3_bucket_policy.trail_logs]
}

# --- Saída do módulo ---
output "cloudtrail_name" {
  description = "Nome da trilha CloudTrail."
  value       = aws_cloudtrail.governance.name
}
