"""
index.py - CHECKLIST Wi-Fi (HAMA)
Lambda que SIMULA um teste de conectividade Wi-Fi e publica a métrica
de latência/disponibilidade no CloudWatch (namespace HAMA/Wifi).

Em produção, esta mesma lógica rodaria em um agente on-premise
(ex.: dispositivo com SSM Agent) que mede a rede real do hospital
e envia a métrica para o mesmo namespace.
"""

import os
import random
import boto3

cloudwatch = boto3.client("cloudwatch")

# Pontos de acesso simulados (correspondem aos setores do hospital).
ACCESS_POINTS = ["UTI", "Recepcao", "CentroCirurgico", "Administrativo", "Laboratorio"]


def handler(event, context):
    resultados = []

    for ap in ACCESS_POINTS:
        # Simula latência (ms) e perda de pacotes (%).
        latencia_ms = round(random.uniform(5, 150), 2)
        perda_pct = round(random.uniform(0, 8), 2)

        # Disponibilidade: 1 = OK, 0 = degradado (perda alta ou latência alta).
        disponivel = 1 if (perda_pct < 5 and latencia_ms < 120) else 0

        # Publica as métricas no CloudWatch.
        cloudwatch.put_metric_data(
            Namespace="HAMA/Wifi",
            MetricData=[
                {
                    "MetricName": "LatenciaMs",
                    "Dimensions": [{"Name": "AccessPoint", "Value": ap}],
                    "Value": latencia_ms,
                    "Unit": "Milliseconds",
                },
                {
                    "MetricName": "PerdaPacotesPct",
                    "Dimensions": [{"Name": "AccessPoint", "Value": ap}],
                    "Value": perda_pct,
                    "Unit": "Percent",
                },
                {
                    "MetricName": "Disponibilidade",
                    "Dimensions": [{"Name": "AccessPoint", "Value": ap}],
                    "Value": disponivel,
                    "Unit": "None",
                },
            ],
        )

        resultados.append(
            {
                "access_point": ap,
                "latencia_ms": latencia_ms,
                "perda_pct": perda_pct,
                "disponivel": bool(disponivel),
            }
        )

    return {
        "statusCode": 200,
        "checklist": "Wi-Fi",
        "documento": "CHECKLIST.HAMA.TI - Wi-Fi",
        "resultados": resultados,
    }
