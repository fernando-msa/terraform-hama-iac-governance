############################################################
# modules/tags/variables.tf
# Entradas do módulo de tags (DIR.MMLN.TI.001).
############################################################

variable "setor" {
  description = "Setor proprietário do ativo."
  type        = string
}

variable "data_aquisicao" {
  description = "Data de aquisição (AAAA-MM-DD)."
  type        = string
}

variable "data_fim_vida" {
  description = "Data de fim de vida calculada (AAAA-MM-DD)."
  type        = string
}

variable "responsavel" {
  description = "Responsável técnico pelo ativo."
  type        = string
}

variable "custo_centro" {
  description = "Centro de custo."
  type        = string
}
