############################################################
# variables.tf
# Variáveis globais do projeto de governança HAMA.
# Convenção: nomes de variáveis em inglês, comentários em PT-BR.
############################################################

# Região AWS onde os recursos serão criados.
# us-east-1 é recomendada por ter ampla cobertura de Free Tier.
variable "aws_region" {
  description = "Região AWS de deploy (elegível ao Free Tier)."
  type        = string
  default     = "us-east-1"

  validation {
    # Restringimos a regiões comuns para evitar erros de digitação.
    condition     = contains(["us-east-1", "us-east-2", "sa-east-1"], var.aws_region)
    error_message = "Use uma região suportada: us-east-1, us-east-2 ou sa-east-1."
  }
}

# Prefixo aplicado a nomes de recursos para padronização (DIR.MMLN.TI.001).
variable "project_prefix" {
  description = "Prefixo de nomenclatura dos recursos."
  type        = string
  default     = "hama"

  validation {
    condition     = can(regex("^[a-z0-9-]{2,12}$", var.project_prefix))
    error_message = "O prefixo deve ter 2-12 caracteres minúsculos, números ou hífen."
  }
}

############################################################
# TAGS OBRIGATÓRIAS - DIR.MMLN.TI.001 (Gestão de Ativos)
############################################################

# Setor responsável pelo ativo (ex.: TI-Infraestrutura, UTI, Recepção).
variable "setor" {
  description = "Setor proprietário do ativo (tag Setor)."
  type        = string

  validation {
    condition     = length(var.setor) > 1
    error_message = "Informe um setor válido."
  }
}

# Data de aquisição do ativo no formato AAAA-MM-DD.
variable "data_aquisicao" {
  description = "Data de aquisição do ativo (AAAA-MM-DD)."
  type        = string

  validation {
    condition     = can(regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", var.data_aquisicao))
    error_message = "Use o formato de data AAAA-MM-DD (ex.: 2025-01-15)."
  }
}

# Responsável técnico pelo ativo.
variable "responsavel" {
  description = "Responsável técnico (tag Responsavel)."
  type        = string

  validation {
    condition     = length(var.responsavel) > 2
    error_message = "Informe o nome/cargo do responsável."
  }
}

# Centro de custo contábil do ativo.
variable "custo_centro" {
  description = "Centro de custo (tag CustoCentro)."
  type        = string

  validation {
    condition     = can(regex("^CC-[A-Z]{2,4}-[0-9]{3}$", var.custo_centro))
    error_message = "Formato esperado: CC-XX-000 (ex.: CC-TI-001)."
  }
}

# Vida útil do ativo em anos (DIR.MMLN.TI.001 define 8 anos).
variable "vida_util_anos" {
  description = "Vida útil do ativo em anos (calcula DataFimVida)."
  type        = number
  default     = 8

  validation {
    condition     = var.vida_util_anos >= 1 && var.vida_util_anos <= 15
    error_message = "A vida útil deve estar entre 1 e 15 anos."
  }
}

############################################################
# MONITORAMENTO / SLA - POP.HAMA.TI.005
############################################################

# Limite de SLA: tempo máximo de resposta de chamado em minutos.
variable "sla_tempo_resposta_min" {
  description = "Limite (min) de tempo de resposta de chamado para o alarme de SLA."
  type        = number
  default     = 120

  validation {
    condition     = var.sla_tempo_resposta_min > 0
    error_message = "O SLA deve ser maior que zero."
  }
}

# E-mail que receberá as notificações de alarme (via SNS).
variable "alarme_email" {
  description = "E-mail para notificações de alarme de SLA."
  type        = string

  validation {
    condition     = can(regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$", var.alarme_email))
    error_message = "Informe um e-mail válido."
  }
}

############################################################
# BACKUP - POP.HAMA.TI.004
############################################################

# Dias até a expiração dos objetos de backup (lifecycle).
variable "backup_retencao_dias" {
  description = "Dias de retenção dos backups antes da expiração."
  type        = number
  default     = 30

  validation {
    condition     = var.backup_retencao_dias >= 1 && var.backup_retencao_dias <= 365
    error_message = "A retenção deve estar entre 1 e 365 dias."
  }
}
