############################################################
# outputs.tf
# Saídas úteis para validação e documentação da entrega.
############################################################

output "conta_aws" {
  description = "ID da conta AWS onde os recursos foram criados."
  value       = data.aws_caller_identity.current.account_id
}

output "regiao" {
  description = "Região AWS de deploy."
  value       = data.aws_region.current.name
}

output "tags_aplicadas" {
  description = "Tags obrigatórias aplicadas a todos os recursos (DIR.MMLN.TI.001)."
  value       = module.tags.tags
}

output "backup_bucket_name" {
  description = "Nome do bucket de backup (POP.HAMA.TI.004)."
  value       = module.backup.bucket_name
}

output "sla_alarm_name" {
  description = "Nome do alarme de SLA (POP.HAMA.TI.005)."
  value       = module.monitoring.sla_alarm_name
}

output "wifi_check_lambda_name" {
  description = "Nome da Lambda de checagem de Wi-Fi (Checklist Wi-Fi)."
  value       = module.monitoring.wifi_check_lambda_name
}

output "tecnico_rack_role_arn" {
  description = "ARN da role tecnico_rack (FORM.HAMA.TI.015)."
  value       = module.policies.tecnico_rack_role_arn
}

output "cloudtrail_name" {
  description = "Nome da trilha de auditoria CloudTrail."
  value       = module.logs.cloudtrail_name
}
