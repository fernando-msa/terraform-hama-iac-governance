############################################################
# modules/tags/main.tf
# Módulo de tags - DIR.MMLN.TI.001 (Gestão de Ativos).
# Centraliza e VALIDA o conjunto de tags obrigatórias.
############################################################

locals {
  # Monta o mapa final de tags obrigatórias.
  tags = {
    Setor         = var.setor
    DataAquisicao = var.data_aquisicao
    DataFimVida   = var.data_fim_vida
    Responsavel   = var.responsavel
    CustoCentro   = var.custo_centro
    ManagedBy     = "Terraform"
    Governanca    = "DIR.MMLN.TI.001"
  }
}

# Recurso "null" usado apenas para falhar o plan/apply caso alguma
# tag obrigatória venha vazia (defesa extra além das validations).
resource "null_resource" "tags_guard" {
  lifecycle {
    precondition {
      condition = alltrue([
        var.setor != "",
        var.data_aquisicao != "",
        var.data_fim_vida != "",
        var.responsavel != "",
        var.custo_centro != "",
      ])
      error_message = "Todas as tags obrigatórias (DIR.MMLN.TI.001) devem estar preenchidas."
    }
  }
}
