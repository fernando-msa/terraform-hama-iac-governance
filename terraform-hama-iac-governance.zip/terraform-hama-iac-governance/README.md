# terraform-hama-iac-governance

> Infraestrutura como Código (IaC) que implementa, de forma automatizada e auditável, os controles de governança de TI do **HAMA – Hospital de Aracaju/SE**.
> Cada recurso AWS provisionado aqui corresponde diretamente a uma **DIRETRIZ**, **POP** ou **CHECKLIST** documentado pela área de Infraestrutura, traduzindo normas **ISO/IEC 27001** e **LGPD** em código versionável.

---

## 🎯 Objetivo

Demonstrar a capacidade de transformar **processos e normas em papel** em **controles técnicos vivos** (Policy as Code / Infrastructure as Code), garantindo:

- **Rastreabilidade** de ativos (tagging obrigatório).
- **Conformidade preventiva** (bloqueio de recursos fora do padrão).
- **Continuidade** (backup versionado com ciclo de vida).
- **Observabilidade** (alarmes de SLA e checagem de Wi-Fi).
- **Auditoria** (CloudTrail + IAM com menor privilégio).

Todos os recursos foram escolhidos para serem **elegíveis ao AWS Free Tier** (serverless: S3, Lambda, CloudWatch, IAM, CloudTrail). **Nenhum recurso pago** (NAT Gateway, ALB, EC2 paga) é criado.

---

## 🗺️ Tabela de Correlação (Documento ↔ Recurso)

| Documento de Governança | Controle | Recurso Terraform | Onde no código |
|---|---|---|---|
| **DIR.MMLN.TI.001** – Gestão de ativos | Tags obrigatórias (Setor, DataAquisicao, DataFimVida 8 anos, Responsavel, CustoCentro) | `module.tags` (locals + `default_tags` no provider) | `modules/tags/`, `main.tf` |
| **DIR.MMLN.TI.002** – Políticas de restrição | Bloqueio de recursos sem tags obrigatórias | IAM Policy de negação + SCP de exemplo | `policies/iam-policies.tf`, `policies/scp-blocklist.json` |
| **POP.HAMA.TI.004** – Backup | Bucket S3 com versionamento + lifecycle (expira 30 dias) | `aws_s3_bucket` + versioning + lifecycle | `modules/backup/s3-bucket.tf` |
| **POP.HAMA.TI.005** – SLA / Monitoramento | Alarme de tempo de resposta de chamado | `aws_cloudwatch_metric_alarm` | `modules/monitoring/cloudwatch-alarms.tf` |
| **FORM.HAMA.TI.015** – Controle de acesso | Role `tecnico_rack` com permissões limitadas + log de acesso | `aws_iam_role` + CloudTrail | `policies/iam-policies.tf`, `logs/cloudtrail-logs.tf` |
| **CHECKLIST Wi-Fi** | Teste de conectividade simulado + publicação de métrica | `aws_lambda_function` (Python) | `modules/monitoring/lambda-wifi-check/` |
| **POP.HAMA.TI – Sala de Rack / Auditoria** | Trilha de auditoria de todas as ações | `aws_cloudtrail` + bucket de logs | `logs/cloudtrail-logs.tf` |

---

## 🏛️ Diagrama de Arquitetura

```mermaid
flowchart TD
    subgraph GOV["Governança como Código - HAMA"]
        TAGS["Módulo Tags<br/>DIR.MMLN.TI.001<br/>Setor / DataAquisicao / DataFimVida / Responsavel / CustoCentro"]
    end

    subgraph SEC["Conformidade & Acesso"]
        SCP["SCP / IAM Deny<br/>DIR.MMLN.TI.002<br/>bloqueia recursos sem tags"]
        ROLE["IAM Role: tecnico_rack<br/>FORM.HAMA.TI.015<br/>menor privilegio"]
    end

    subgraph OPS["Operacoes"]
        S3BK["S3 Backup<br/>POP.HAMA.TI.004<br/>versionamento + lifecycle 30d"]
        ALARM["CloudWatch Alarm<br/>POP.HAMA.TI.005<br/>SLA tempo de resposta"]
        LAMBDA["Lambda wifi-check<br/>CHECKLIST Wi-Fi<br/>publica metrica"]
    end

    subgraph AUD["Auditoria"]
        TRAIL["CloudTrail<br/>+ S3 de logs"]
    end

    TAGS --> S3BK
    TAGS --> ROLE
    TAGS --> LAMBDA
    SCP --> S3BK
    LAMBDA -->|PutMetricData| ALARM
    ROLE --> TRAIL
    S3BK --> TRAIL
    LAMBDA --> TRAIL
```

---

## ✅ Pré-requisitos

- **AWS CLI** v2 configurado (`aws configure`) com credenciais de uma conta com Free Tier ativo.
- **Terraform** `>= 1.5.0`.
- Permissões IAM para criar S3, Lambda, CloudWatch, IAM, CloudTrail.
- (Opcional) AWS Organizations habilitado **apenas** se quiser aplicar a SCP de verdade (ver seção *Simulação Manual*).

Verifique:

```bash
terraform version   # >= 1.5.0
aws sts get-caller-identity
```

---

## 🚀 Passo a Passo para Deploy

```bash
# 1. Clonar o repositório
git clone https://github.com/<seu-usuario>/terraform-hama-iac-governance.git
cd terraform-hama-iac-governance

# 2. Copiar e editar as variáveis
cp terraform.tfvars.example terraform.tfvars
#   -> ajuste setor, responsavel, custo_centro, e-mail de alarme, etc.

# 3. Inicializar (baixa o provider AWS)
terraform init

# 4. Formatar e validar
terraform fmt -recursive
terraform validate

# 5. Planejar (revisar o que será criado)
terraform plan

# 6. Aplicar
terraform apply

# 7. (Opcional) Destruir tudo ao final da demonstração
terraform destroy
```

---

## 📤 Exemplo de Saída Esperada

```text
Apply complete! Resources: 14 added, 0 changed, 0 destroyed.

Outputs:

backup_bucket_name      = "hama-backup-ti-a1b2c3d4"
cloudtrail_name         = "hama-governance-trail"
sla_alarm_name          = "hama-sla-tempo-resposta-chamado"
tecnico_rack_role_arn   = "arn:aws:iam::123456789012:role/hama-tecnico-rack"
wifi_check_lambda_name  = "hama-wifi-connectivity-check"
tags_aplicadas          = {
  "CustoCentro"   = "CC-TI-001"
  "DataAquisicao" = "2025-01-15"
  "DataFimVida"   = "2033-01-15"
  "Responsavel"   = "Analista de Infraestrutura"
  "Setor"         = "TI-Infraestrutura"
}
```

---

## 🧪 Validação dos Controles após o Deploy

```bash
# Backup com versionamento ativo
aws s3api get-bucket-versioning --bucket $(terraform output -raw backup_bucket_name)

# Invocar a Lambda de Wi-Fi e ver a métrica
aws lambda invoke --function-name $(terraform output -raw wifi_check_lambda_name) /tmp/out.json
cat /tmp/out.json

# Conferir o alarme de SLA
aws cloudwatch describe-alarms --alarm-names $(terraform output -raw sla_alarm_name)
```

---

## ⚠️ O que NÃO é 100% automatizável no Free Tier (e como simular)

| Controle | Limitação | Como demonstrar manualmente |
|---|---|---|
| **SCP real (DIR.MMLN.TI.002)** | SCP exige **AWS Organizations** + conta de gerenciamento. Em conta única não há como anexar. | O arquivo `policies/scp-blocklist.json` está pronto. Em uma org, anexe via `aws organizations attach-policy`. Em conta única, o efeito é **simulado** por uma **IAM Policy de negação** (`iam-policies.tf`) anexada a um grupo de teste. |
| **Métrica de SLA real** | Não há sistema de chamados real publicando métrica. | A Lambda e/ou o comando `aws cloudwatch put-metric-data` injetam um valor manual no namespace `HAMA/SLA` para o alarme disparar na demo. |
| **Wi-Fi físico** | Lambda não alcança a rede interna do hospital. | A `index.py` **simula** latência/perda e publica em `HAMA/Wifi`. Em produção rodaria num device on-prem (ex: SSM Agent) enviando a mesma métrica. |
| **CloudTrail org-wide** | Trilha de organização exige Organizations. | Aqui criamos uma **trail de conta**, suficiente para auditar a demo. |

> 💡 Para a demonstração de SLA disparando o alarme:
> ```bash
> aws cloudwatch put-metric-data --namespace "HAMA/SLA" \
>   --metric-name "TempoRespostaChamadoMin" --value 240
> ```

---

## 📚 Mapeamento ISO 27001 / LGPD (resumo)

- **A.8 Gestão de Ativos** → módulo `tags` + IAM deny.
- **A.5 / A.9 Controle de Acesso** → role `tecnico_rack`, menor privilégio.
- **A.12 Operações / Logs** → CloudTrail, alarmes.
- **A.17 Continuidade** → backup S3 versionado.
- **LGPD Art. 46 (segurança) / Art. 37 (registro de operações)** → CloudTrail + criptografia S3.

---

*Autor: Analista de Infraestrutura – HAMA, Aracaju/SE. Projeto de portfólio.*
