############################################################
# modules/monitoring/lambda-wifi-check/main.tf
# CHECKLIST Wi-Fi - Lambda que simula teste de conectividade
# e publica métrica customizada no CloudWatch (HAMA/Wifi).
############################################################

# Role de execução da Lambda (logs + put-metric-data).
resource "aws_iam_role" "wifi_lambda" {
  name = "${var.project_prefix}-wifi-check-role"

  # Permite que o serviço Lambda assuma esta role.
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
    }]
  })

  tags = var.tags
}

# Permissões mínimas: escrever logs e publicar métricas.
resource "aws_iam_role_policy" "wifi_lambda" {
  name = "${var.project_prefix}-wifi-check-policy"
  role = aws_iam_role.wifi_lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "arn:aws:logs:*:*:*"
      },
      {
        Effect   = "Allow"
        Action   = ["cloudwatch:PutMetricData"]
        Resource = "*"
      }
    ]
  })
}

# Empacota o index.py em um .zip para deploy da Lambda.
data "archive_file" "wifi_zip" {
  type        = "zip"
  source_file = "${path.module}/index.py"
  output_path = "${path.module}/wifi_check.zip"
}

# Função Lambda (Python) - runtime serverless elegível ao Free Tier.
resource "aws_lambda_function" "wifi_check" {
  function_name    = "${var.project_prefix}-wifi-connectivity-check"
  role             = aws_iam_role.wifi_lambda.arn
  handler          = "index.handler"
  runtime          = "python3.12"
  filename         = data.archive_file.wifi_zip.output_path
  source_code_hash = data.archive_file.wifi_zip.output_base64sha256
  timeout          = 30

  tags = var.tags
}

# --- Variáveis do submódulo ---
variable "project_prefix" {
  description = "Prefixo de nomenclatura."
  type        = string
}

variable "tags" {
  description = "Tags obrigatórias."
  type        = map(string)
}

# --- Saídas do submódulo ---
output "lambda_name" {
  description = "Nome da função Lambda de Wi-Fi."
  value       = aws_lambda_function.wifi_check.function_name
}
