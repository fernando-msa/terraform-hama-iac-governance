############################################################
# modules/monitoring/cloudwatch-alarms.tf
# POP.HAMA.TI.005 - SLA / Monitoramento.
# - Tópico SNS para notificar por e-mail.
# - Alarme de SLA (tempo de resposta de chamado).
############################################################

variable "project_prefix" {
  description = "Prefixo de nomenclatura."
  type        = string
}

variable "sla_tempo_resposta_min" {
  description = "Limite de tempo de resposta de chamado (min)."
  type        = number
}

variable "alarme_email" {
  description = "E-mail de notificação do alarme."
  type        = string
}

variable "tags" {
  description = "Tags obrigatórias."
  type        = map(string)
}

# Tópico SNS que recebe os alarmes.
resource "aws_sns_topic" "sla" {
  name = "${var.project_prefix}-sla-notifications"
  tags = var.tags
}

# Inscrição por e-mail (requer confirmação no e-mail após o apply).
resource "aws_sns_topic_subscription" "sla_email" {
  topic_arn = aws_sns_topic.sla.arn
  protocol  = "email"
  endpoint  = var.alarme_email
}

# Alarme de SLA: dispara se o tempo de resposta médio do chamado
# (métrica customizada HAMA/SLA) ultrapassar o limite definido.
resource "aws_cloudwatch_metric_alarm" "sla_tempo_resposta" {
  alarm_name          = "${var.project_prefix}-sla-tempo-resposta-chamado"
  alarm_description   = "POP.HAMA.TI.005 - SLA de tempo de resposta de chamado excedido."
  namespace           = "HAMA/SLA"
  metric_name         = "TempoRespostaChamadoMin"
  statistic           = "Average"
  period              = 300
  evaluation_periods  = 1
  threshold           = var.sla_tempo_resposta_min
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  alarm_actions = [aws_sns_topic.sla.arn]
  ok_actions    = [aws_sns_topic.sla.arn]

  tags = var.tags
}

output "sla_alarm_name" {
  description = "Nome do alarme de SLA."
  value       = aws_cloudwatch_metric_alarm.sla_tempo_resposta.alarm_name
}
