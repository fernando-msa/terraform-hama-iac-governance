############################################################
# policies/iam-policies.tf  (MÓDULO ./policies)
# DIR.MMLN.TI.002 - Políticas de restrição (Policy as Code).
# FORM.HAMA.TI.015 - Controle de acesso (role tecnico_rack).
############################################################

# --- Entradas do módulo ---
variable "project_prefix" {
  description = "Prefixo de nomenclatura."
  type        = string
}

variable "tags" {
  description = "Tags obrigatórias herdadas do módulo de tags."
  type        = map(string)
}

variable "account_id" {
  description = "ID da conta AWS (vindo do data source no root)."
  type        = string
}

############################################################
# 1) DIR.MMLN.TI.002 - Negar criação de recursos SEM tags.
#    Em conta única (sem Organizations) usamos uma IAM Policy
#    de NEGAÇÃO anexada a um grupo de teste, simulando a SCP.
############################################################

resource "aws_iam_policy" "deny_untagged" {
  name        = "${var.project_prefix}-deny-untagged-resources"
  description = "DIR.MMLN.TI.002 - Bloqueia recursos sem tags obrigatorias."

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "NegarSemTagSetor"
        Effect   = "Deny"
        Action   = ["s3:CreateBucket", "ec2:RunInstances"]
        Resource = "*"
        Condition = {
          "Null" = {
            "aws:RequestTag/Setor"       = "true"
            "aws:RequestTag/CustoCentro" = "true"
            "aws:RequestTag/Responsavel" = "true"
          }
        }
      }
    ]
  })

  tags = var.tags
}

# Grupo de teste para demonstrar o efeito da política de restrição.
resource "aws_iam_group" "restritos" {
  name = "${var.project_prefix}-grupo-restrito"
}

resource "aws_iam_group_policy_attachment" "restritos_deny" {
  group      = aws_iam_group.restritos.name
  policy_arn = aws_iam_policy.deny_untagged.arn
}

############################################################
# 2) FORM.HAMA.TI.015 - Role "tecnico_rack" com menor privilégio.
############################################################

resource "aws_iam_role" "tecnico_rack" {
  name = "${var.project_prefix}-tecnico-rack"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { AWS = "arn:aws:iam::${var.account_id}:root" }
    }]
  })

  tags = var.tags
}

resource "aws_iam_role_policy" "tecnico_rack" {
  name = "${var.project_prefix}-tecnico-rack-policy"
  role = aws_iam_role.tecnico_rack.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "LeituraMonitoramento"
        Effect = "Allow"
        Action = [
          "cloudwatch:GetMetricData",
          "cloudwatch:ListMetrics",
          "cloudwatch:DescribeAlarms",
          "tag:GetResources",
          "ec2:DescribeInstances"
        ]
        Resource = "*"
      }
    ]
  })
}

# --- Saída do módulo ---
output "tecnico_rack_role_arn" {
  description = "ARN da role tecnico_rack."
  value       = aws_iam_role.tecnico_rack.arn
}
