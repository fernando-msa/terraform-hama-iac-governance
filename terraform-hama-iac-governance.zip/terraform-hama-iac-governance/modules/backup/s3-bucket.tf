############################################################
# modules/backup/s3-bucket.tf
# POP.HAMA.TI.004 - Backup.
# Bucket S3 com: versionamento, criptografia, bloqueio público
# e lifecycle (expira objetos após N dias).
############################################################

# Variáveis locais do módulo (declaradas aqui por simplicidade).
variable "bucket_name" {
  description = "Nome global único do bucket de backup."
  type        = string
}

variable "retencao_dias" {
  description = "Dias até expirar os objetos (lifecycle)."
  type        = number
}

variable "tags" {
  description = "Tags obrigatórias herdadas do módulo de tags."
  type        = map(string)
}

# Bucket principal de backup.
resource "aws_s3_bucket" "backup" {
  bucket = var.bucket_name
  tags   = var.tags
}

# Versionamento ATIVO - permite recuperar versões anteriores (continuidade).
resource "aws_s3_bucket_versioning" "backup" {
  bucket = aws_s3_bucket.backup.id

  versioning_configuration {
    status = "Enabled"
  }
}

# Criptografia em repouso (SSE-S3) - requisito LGPD/ISO 27001.
resource "aws_s3_bucket_server_side_encryption_configuration" "backup" {
  bucket = aws_s3_bucket.backup.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# Bloqueio total de acesso público (dados sensíveis de saúde).
resource "aws_s3_bucket_public_access_block" "backup" {
  bucket = aws_s3_bucket.backup.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Lifecycle: expira objetos atuais e versões antigas após a retenção.
resource "aws_s3_bucket_lifecycle_configuration" "backup" {
  bucket = aws_s3_bucket.backup.id

  rule {
    id     = "expira-backups"
    status = "Enabled"

    filter {} # aplica a todos os objetos

    # Expira a versão atual após N dias.
    expiration {
      days = var.retencao_dias
    }

    # Remove versões não-atuais após N dias (limpeza do versionamento).
    noncurrent_version_expiration {
      noncurrent_days = var.retencao_dias
    }
  }
}

output "bucket_name" {
  description = "Nome do bucket de backup."
  value       = aws_s3_bucket.backup.id
}

output "bucket_arn" {
  description = "ARN do bucket de backup."
  value       = aws_s3_bucket.backup.arn
}
