############################################################
# modules/monitoring/main.tf
# Compõe o submódulo da Lambda de Wi-Fi e reexpõe sua saída.
# (As variáveis project_prefix/tags já são declaradas em
#  cloudwatch-alarms.tf, então aqui apenas reutilizamos.)
############################################################

module "wifi_check" {
  source = "./lambda-wifi-check"

  project_prefix = var.project_prefix
  tags           = var.tags
}

output "wifi_check_lambda_name" {
  description = "Nome da Lambda de checagem de Wi-Fi."
  value       = module.wifi_check.lambda_name
}
